<template>
  <cover-layout>
     <main class="d-flex flex-grow-1">
        <div class="w-full">
          <section
            class="
              pt-10
              bg-danger-fun
              pb-16
              py-md-20
              position-relative
              overflow-hidden
            "
          >
            <div class="container-lg">
              <div class="row">
                <div class="col-md-7">
                  <h1 class="lh-tight ls-tight display-4 mb-7">
                    Avez-vous un rêves...
                    <span class="d-inline-flex text-gray-300 position-relative">
                      <span
                        aria-hidden="true"
                        class="
                          d-inline
                          position-absolute
                          h-3
                          inset-x-0
                          bottom-0
                          bg-cyan-100
                          transform
                          scale-105
                          rounded
                        "
                      ></span>
                      <span class="position-relative text-danger"
                        >Concrétisons là !</span
                      >
                    </span>
                  </h1>
                  <p
                    class="text-muted lead font-regular mb-7 mb-md-10 pe-lg-24"
                  >
                    Des millioons dde personnes réalisent leurs rêves en partant
                    de rien. Nous avions aidez des centaines de personnes à le
                    faire, nous pouvons vous aider aussi à y arriver même avec
                    peu de moyens...
                  </p>
                  <div class="py-2">
                    <a
                      class="btn btn-white rounded-lg border-1 shadow-sm"
                      href=""
                      >En savoir plus -></a
                    >
                  </div>
                </div>
                <div class="col-md-5"></div>
              </div>
            </div>
          </section>
          <section>
            <div class="pb-24 pb-lg-26 pt-lg-32">
              <div class="container-xl max-w-screen-xl">
                <div class="row align-items-center">
                  <div class="col-lg-6 order-lg-2 offset-lg-0 mb-10 mb-lg-0">
                    <h5 class="text-uppercase text-muted mb-5">
                      QUI SOMMES NOUS ?
                    </h5>

                    <!-- Heading -->
                    <h1 class="lh-tight ls-tight display-5 mb-7">
                      Une équipe de jeunes passionnées, pour
                      <span
                        class="d-inline-flex text-warning position-relative"
                      >
                        <span
                          aria-hidden="true"
                          class="
                            d-inline
                            position-absolute
                            h-3
                            inset-x-0
                            bottom-0
                            bg-warning
                            -700
                            transform
                            scale-105
                            rounded
                          "
                        ></span>
                        <span class="position-relative"> vous servir </span>
                      </span>
                    </h1>
                    <!-- Text -->
                    <p class="text-lg lead mb-7">
                      La réalisation d'une idée, d'un projet digital qui permet
                      d'atteindre des objectifs de réussite à long terme
                      nécessite des ressources humaines qualifiées et
                      passionnées par ce qu'ils font. Nul n'entre à Odacesoft
                      s'il n'est passionné
                    </p>

                    <div class="d-flex mx-n1 mb-7">
                      <a
                        class="
                          d-inline-block
                          link-warning
                          text-md
                          font-semibold
                          px-2
                          my-2
                          mx-md-2
                          w-full w-md-auto
                        "
                        href="/equipe"
                        >Découvrir l'équipe -></a
                      >
                    </div>
                  </div>

                  <div
                    class="
                      col-12 col-md-12 col-lg-6
                      order-lg-1
                      p-0
                      position-relative
                    "
                  >
                    <div class="position-relative overlap-10">
                      <img
                        src="storages/assets/img/web/odacesoft-team.jpg"
                        class="img-fluid rounded-5"
                        alt="Component library features"
                      />
                    </div>

                    <!-- Decorations -->
                    <div
                      class="
                        d-none d-lg-inline-block
                        position-absolute
                        top-0
                        start-0
                        w-64
                        h-64
                        mt-n10
                        ms-n10
                        text-muted
                      "
                    >
                      <svg
                        width="185"
                        height="186"
                        viewBox="0 0 185 186"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <circle
                          cx="2"
                          cy="2"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="22"
                          cy="2"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="42"
                          cy="2"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="62"
                          cy="2"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="82"
                          cy="2"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="102"
                          cy="2"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="122"
                          cy="2"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="142"
                          cy="2"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="162"
                          cy="2"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="182"
                          cy="2"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="2"
                          cy="22"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="22"
                          cy="22"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="42"
                          cy="22"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="62"
                          cy="22"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="82"
                          cy="22"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="102"
                          cy="22"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="122"
                          cy="22"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="142"
                          cy="22"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="162"
                          cy="22"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="182"
                          cy="22"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="2"
                          cy="42"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="22"
                          cy="42"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="42"
                          cy="42"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="62"
                          cy="42"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="82"
                          cy="42"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="102"
                          cy="42"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="122"
                          cy="42"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="142"
                          cy="42"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="162"
                          cy="42"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="182"
                          cy="42"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="2"
                          cy="62"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="22"
                          cy="62"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="42"
                          cy="62"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="62"
                          cy="62"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="82"
                          cy="62"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="102"
                          cy="62"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="122"
                          cy="62"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="142"
                          cy="62"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="162"
                          cy="62"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="182"
                          cy="62"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="2"
                          cy="82"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="22"
                          cy="82"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="42"
                          cy="82"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="62"
                          cy="82"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="82"
                          cy="82"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="102"
                          cy="82"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="122"
                          cy="82"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="142"
                          cy="82"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="162"
                          cy="82"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="182"
                          cy="82"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="2"
                          cy="102"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="22"
                          cy="102"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="42"
                          cy="102"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="62"
                          cy="102"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="82"
                          cy="102"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="102"
                          cy="102"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="122"
                          cy="102"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="142"
                          cy="102"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="162"
                          cy="102"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="182"
                          cy="102"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="2"
                          cy="122"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="22"
                          cy="122"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="42"
                          cy="122"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="62"
                          cy="122"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="82"
                          cy="122"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="102"
                          cy="122"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="122"
                          cy="122"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="142"
                          cy="122"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="162"
                          cy="122"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="182"
                          cy="122"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="2"
                          cy="142"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="22"
                          cy="142"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="42"
                          cy="142"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="62"
                          cy="142"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="82"
                          cy="142"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="102"
                          cy="142"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="122"
                          cy="142"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="142"
                          cy="142"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="162"
                          cy="142"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="182"
                          cy="142"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="2"
                          cy="162"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="22"
                          cy="162"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="42"
                          cy="162"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="62"
                          cy="162"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="82"
                          cy="162"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="102"
                          cy="162"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="122"
                          cy="162"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="142"
                          cy="162"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="162"
                          cy="162"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="182"
                          cy="162"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="2"
                          cy="182"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="22"
                          cy="182"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="42"
                          cy="182"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="62"
                          cy="182"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="82"
                          cy="182"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="102"
                          cy="182"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="122"
                          cy="182"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="142"
                          cy="182"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="162"
                          cy="182"
                          r="2"
                          fill="currentColor"
                        ></circle>
                        <circle
                          cx="182"
                          cy="182"
                          r="2"
                          fill="currentColor"
                        ></circle>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <section class="bg-success-fun_ bg-surface-secondary">
            <div class="py-16 py-md-24 py-lg-32 position-relative">
              <div class="container-lg max-w-screen-xl">
                <!-- Title -->
                <div class="row align-items-center mb-16">
                  <div
                    class="col-12 col-md-10 col-lg-10 mx-lg-auto text-lg-center"
                  >
                    <section>
                      <h1 class="lh-tight ls-tight display-5 mb-8">
                        Des services
                        <span class="font-weight-light">minitieusement</span>
                        choisis pour atteindre
                        <span class="text-success"> vos buts.</span>
                      </h1>

                      <p class="text-lg px-lg-32">
                        Nous ne nous engageons dans le fourniture d'un service
                        que si nous en avons les moyens. Chaque service est
                        fourni à 360° afin de vous garantir une meilleure
                        expérience client.
                      </p>
                    </section>
                  </div>
                </div>

                <!-- Content -->
                <div class="row g-7 g-lg-7">
                  <div class="col-12 col-md-6 col-lg-4">
                    <div class="card border-0 shadow-4 shadow-6-hover">
                      <div class="p-5 p-md-5 p-xl-10">
                        <section>
                          <header>
                            <div
                              class="
                                icon icon-xl
                                svg-current
                                text-success
                                mb-8
                                mx-n2
                              "
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="16"
                                height="16"
                                fill="currentColor"
                                class="bi bi-grid-3x3-gap"
                                viewBox="0 0 16 16"
                              >
                                <path
                                  d="M4 2v2H2V2h2zm1 12v-2a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1zm0-5V7a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1zm0-5V2a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1zm5 10v-2a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1zm0-5V7a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1zm0-5V2a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1zM9 2v2H7V2h2zm5 0v2h-2V2h2zM4 7v2H2V7h2zm5 0v2H7V7h2zm5 0h-2v2h2V7zM4 12v2H2v-2h2zm5 0v2H7v-2h2zm5 0v2h-2v-2h2zM12 1a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1h-2zm-1 6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1V7zm1 4a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1h-2z"
                                />
                              </svg>
                            </div>

                            <h1 class="h3 mb-4">Conception de logiciels</h1>
                          </header>

                          <!-- Text -->
                          <p class="text-muted mb-5">
                            Get working prototypes to your clients lightning
                            fast and deliver production-ready pages.
                          </p>

                          <footer>
                            <a
                              href="start.html"
                              class="font-semibold link-success stretched-link"
                              >Plus d'infos -></a
                            >
                          </footer>
                        </section>
                      </div>
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-4">
                    <div class="card border-0 shadow-4 shadow-6-hover">
                      <div class="p-5 p-md-5 p-xl-10">
                        <section>
                          <header>
                            <div
                              class="
                                icon icon-xl
                                svg-current
                                text-warning
                                mb-8
                                mx-n2
                              "
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="16"
                                height="16"
                                fill="currentColor"
                                class="bi bi-menu-button-wide-fill"
                                viewBox="0 0 16 16"
                              >
                                <path
                                  d="M1.5 0A1.5 1.5 0 0 0 0 1.5v2A1.5 1.5 0 0 0 1.5 5h13A1.5 1.5 0 0 0 16 3.5v-2A1.5 1.5 0 0 0 14.5 0h-13zm1 2h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1 0-1zm9.927.427A.25.25 0 0 1 12.604 2h.792a.25.25 0 0 1 .177.427l-.396.396a.25.25 0 0 1-.354 0l-.396-.396zM0 8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V8zm1 3v2a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2H1zm14-1V8a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1v2h14zM2 8.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0 4a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5z"
                                />
                              </svg>
                            </div>

                            <h1 class="h3 mb-4">Sites et Applications Web</h1>
                          </header>

                          <!-- Text -->
                          <p class="text-muted mb-5">
                            Get working prototypes to your clients lightning
                            fast and deliver production-ready pages.
                          </p>

                          <footer>
                            <a
                              href="start.html"
                              class="font-semibold link-warning stretched-link"
                              >Plus d'infos -></a
                            >
                          </footer>
                        </section>
                      </div>
                    </div>
                  </div>

                  <div class="col-12 col-md-6 col-lg-4">
                    <div class="card border-0 shadow-4 shadow-6-hover">
                      <div class="p-5 p-md-5 p-xl-10">
                        <section>
                          <header>
                            <div
                              class="
                                icon icon-xl
                                svg-current
                                text-tertiary
                                mb-8
                                mx-n2
                              "
                            >
                              <svg
                                width="24"
                                height="24"
                                viewBox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                              >
                                <path
                                  opacity="0.3"
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M18.5 8C17.1193 8 16 6.88071 16 5.5C16 4.11929 17.1193 3 18.5 3C19.8807 3 21 4.11929 21 5.5C21 6.88071 19.8807 8 18.5 8ZM18.5 21C17.1193 21 16 19.8807 16 18.5C16 17.1193 17.1193 16 18.5 16C19.8807 16 21 17.1193 21 18.5C21 19.8807 19.8807 21 18.5 21ZM5.5 21C4.11929 21 3 19.8807 3 18.5C3 17.1193 4.11929 16 5.5 16C6.88071 16 8 17.1193 8 18.5C8 19.8807 6.88071 21 5.5 21Z"
                                  fill="black"
                                />
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M5.5 8C4.11929 8 3 6.88071 3 5.5C3 4.11929 4.11929 3 5.5 3C6.88071 3 8 4.11929 8 5.5C8 6.88071 6.88071 8 5.5 8ZM11 4H13C13.5523 4 14 4.44772 14 5C14 5.55228 13.5523 6 13 6H11C10.4477 6 10 5.55228 10 5C10 4.44772 10.4477 4 11 4ZM11 18H13C13.5523 18 14 18.4477 14 19C14 19.5523 13.5523 20 13 20H11C10.4477 20 10 19.5523 10 19C10 18.4477 10.4477 18 11 18ZM5 10C5.55228 10 6 10.4477 6 11V13C6 13.5523 5.55228 14 5 14C4.44772 14 4 13.5523 4 13V11C4 10.4477 4.44772 10 5 10ZM19 10C19.5523 10 20 10.4477 20 11V13C20 13.5523 19.5523 14 19 14C18.4477 14 18 13.5523 18 13V11C18 10.4477 18.4477 10 19 10Z"
                                  fill="black"
                                />
                              </svg>
                            </div>

                            <h1 class="h3 mb-4">Design Graphique</h1>
                          </header>

                          <!-- Text -->
                          <p class="text-muted mb-5">
                            Get working prototypes to your clients lightning
                            fast and deliver production-ready pages.
                          </p>

                          <footer>
                            <a
                              href="start.html"
                              class="font-semibold link-tertiary stretched-link"
                              >Plus d'infos -></a
                            >
                          </footer>
                        </section>
                      </div>
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-4">
                    <div class="card border-0 shadow-4 shadow-6-hover">
                      <div class="p-5 p-md-5 p-xl-10">
                        <section>
                          <header>
                            <div
                              class="
                                icon icon-xl
                                svg-current
                                text-gray-700
                                mb-8
                                mx-n2
                              "
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="16"
                                height="16"
                                fill="currentColor"
                                class="bi bi-megaphone"
                                viewBox="0 0 16 16"
                              >
                                <path
                                  d="M13 2.5a1.5 1.5 0 0 1 3 0v11a1.5 1.5 0 0 1-3 0v-.214c-2.162-1.241-4.49-1.843-6.912-2.083l.405 2.712A1 1 0 0 1 5.51 15.1h-.548a1 1 0 0 1-.916-.599l-1.85-3.49a68.14 68.14 0 0 0-.202-.003A2.014 2.014 0 0 1 0 9V7a2.02 2.02 0 0 1 1.992-2.013 74.663 74.663 0 0 0 2.483-.075c3.043-.154 6.148-.849 8.525-2.199V2.5zm1 0v11a.5.5 0 0 0 1 0v-11a.5.5 0 0 0-1 0zm-1 1.35c-2.344 1.205-5.209 1.842-8 2.033v4.233c.18.01.359.022.537.036 2.568.189 5.093.744 7.463 1.993V3.85zm-9 6.215v-4.13a95.09 95.09 0 0 1-1.992.052A1.02 1.02 0 0 0 1 7v2c0 .55.448 1.002 1.006 1.009A60.49 60.49 0 0 1 4 10.065zm-.657.975 1.609 3.037.01.024h.548l-.002-.014-.443-2.966a68.019 68.019 0 0 0-1.722-.082z"
                                />
                              </svg>
                            </div>

                            <h1 class="h3 mb-4">Marketing et Com. Digitale</h1>
                          </header>

                          <!-- Text -->
                          <p class="text-muted mb-5">
                            Get working prototypes to your clients lightning
                            fast and deliver production-ready pages.
                          </p>

                          <footer>
                            <a
                              href="start.html"
                              class="font-semibold text-dark stretched-link"
                              >Plus d'infos -></a
                            >
                          </footer>
                        </section>
                      </div>
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-4">
                    <div class="card border-0 shadow-4 shadow-6-hover">
                      <div class="p-5 p-md-5 p-xl-10">
                        <section>
                          <header>
                            <div
                              class="
                                icon icon-xl
                                svg-current
                                text-danger
                                mb-8
                                mx-n2
                              "
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="16"
                                height="16"
                                fill="currentColor"
                                class="bi bi-hdd-network"
                                viewBox="0 0 16 16"
                              >
                                <path
                                  d="M4.5 5a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1zM3 4.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0z"
                                />
                                <path
                                  d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v1a2 2 0 0 1-2 2H8.5v3a1.5 1.5 0 0 1 1.5 1.5h5.5a.5.5 0 0 1 0 1H10A1.5 1.5 0 0 1 8.5 14h-1A1.5 1.5 0 0 1 6 12.5H.5a.5.5 0 0 1 0-1H6A1.5 1.5 0 0 1 7.5 10V7H2a2 2 0 0 1-2-2V4zm1 0v1a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1zm6 7.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5z"
                                />
                              </svg>
                            </div>

                            <h1 class="h3 mb-4">Installation Réseaux</h1>
                          </header>

                          <!-- Text -->
                          <p class="text-muted mb-5">
                            Get working prototypes to your clients lightning
                            fast and deliver production-ready pages.
                          </p>

                          <footer>
                            <a
                              href="start.html"
                              class="font-semibold link-danger stretched-link"
                              >Plus d'infos -></a
                            >
                          </footer>
                        </section>
                      </div>
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-4">
                    <div class="card border-0 shadow-4 shadow-6-hover">
                      <div class="p-5 p-md-5 p-xl-10">
                        <section>
                          <header>
                            <div
                              class="
                                icon icon-xl
                                svg-current
                                text-primary
                                mb-8
                                mx-n2
                              "
                            >
                              <svg
                                width="24"
                                height="24"
                                viewBox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                              >
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M5.5 4H9.5C10.3284 4 11 4.67157 11 5.5V6.5C11 7.32843 10.3284 8 9.5 8H5.5C4.67157 8 4 7.32843 4 6.5V5.5C4 4.67157 4.67157 4 5.5 4ZM14.5 16H18.5C19.3284 16 20 16.6716 20 17.5V18.5C20 19.3284 19.3284 20 18.5 20H14.5C13.6716 20 13 19.3284 13 18.5V17.5C13 16.6716 13.6716 16 14.5 16Z"
                                  fill="black"
                                />
                                <path
                                  opacity="0.3"
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M5.5 10H9.5C10.3284 10 11 10.6716 11 11.5V18.5C11 19.3284 10.3284 20 9.5 20H5.5C4.67157 20 4 19.3284 4 18.5V11.5C4 10.6716 4.67157 10 5.5 10ZM14.5 4H18.5C19.3284 4 20 4.67157 20 5.5V12.5C20 13.3284 19.3284 14 18.5 14H14.5C13.6716 14 13 13.3284 13 12.5V5.5C13 4.67157 13.6716 4 14.5 4Z"
                                  fill="black"
                                />
                              </svg>
                            </div>

                            <h1 class="h3 mb-5">Expertise et Formation</h1>
                          </header>

                          <!-- Text -->
                          <p class="text-muted mb-4">
                            Profesionally designed and fully coded HTML
                            components for Bootstrap 5 to build beautiful,
                            dynamic websites.
                          </p>

                          <footer>
                            <a
                              href="components.html"
                              class="font-semibold link-primary stretched-link"
                              >Start using -></a
                            >
                          </footer>
                        </section>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <section>
            <div class="pt-24 pt-lg-40 pb-40">
              <div class="container-lg max-w-screen-xl">
                <div class="row align-items-center mb-16">
                  <div class="col-lg-12 text-center">
                    <!-- Badge -->
                    <h5 class="text-uppercase text-danger mb-1">
                      Pour leurs réalisations
                    </h5>

                    <!-- Heading -->
                    <h1 class="lh-tight ls-tight display-5 mb-5">
                      Ils nous font confiance
                    </h1>

                    <!-- Text -->
                    <p class="text-lg">
                      Why reinvent the wheel when there is a great solution
                      ready for you to start building your apps? Use our
                      components and design system as the rock-solid foundation
                      for your internal UI component library to:
                    </p>
                  </div>
                </div>
                <div class="row mt-20">
                  <div class="col-lg-12 mx-auto">
                    <div class="row g-16">
                      <div class="col-sm-6 col-md-4">
                        <section>
                          <div class="icon icon-lg text-primary mb-5">
                            <i class="far fa-user-clock"></i>
                          </div>

                          <h1 class="h4 mb-2">Save time and money</h1>

                          <p>
                            Save time building powerful, sleek and modern
                            websites and apps.
                          </p>
                        </section>
                      </div>
                      <div class="col-sm-6 col-md-4">
                        <section>
                          <div class="icon icon-lg text-primary mb-5">
                            <i class="far fa-object-group"></i>
                          </div>

                          <h1 class="h4 mb-2">Remain consistent</h1>

                          <p>
                            Ensure consistent, modern look-and-feel throughout
                            your UI.
                          </p>
                        </section>
                      </div>
                      <div class="col-sm-6 col-md-4">
                        <section>
                          <div class="icon icon-lg text-primary mb-5">
                            <i class="far fa-user-ninja"></i>
                          </div>

                          <h1 class="h4 mb-2">Stay prepared</h1>

                          <p>
                            Be prepared to handle any new requirements with
                            ease.
                          </p>
                        </section>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </main>
  </cover-layout>
</template>

<script>
    import Header from "./../Components/Header"
    import Notification from "./../Components/Notification"
    import Footer from "./../Components/Footer"
    import CoverLayout from '@/Layouts/CoverLayout'

    export default {
        components:{
            Header,Notification, Footer,CoverLayout
        },
    props: {
        canLogin: Boolean,
        canRegister: Boolean,
        laravelVersion: String,
        phpVersion: String,
    },
    };
</script>
