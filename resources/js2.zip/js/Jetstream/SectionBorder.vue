<template>
    <div class="py-3">
        <hr />
    </div>
</template>
