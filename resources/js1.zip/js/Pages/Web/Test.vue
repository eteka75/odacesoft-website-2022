<template>
  <div>
   <div>Bonjour</div>
  </div>
</template>

<script>
//import HelloWorld from from "@/Components/HelloWorld";

export default {
  name: 'App',
  metaInfo: {
    title: 'Default App Title',
    titleTemplate: '%s | vue-meta Example App'
  },
  components: {
    HelloWorld
  }
}
</script>
