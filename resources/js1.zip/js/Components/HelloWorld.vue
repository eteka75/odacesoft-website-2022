<template>
 <div>
     <div>{{ title }}</div>
 </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  metaInfo: {
    title: 'Hello World!'
  }
}
</script>
