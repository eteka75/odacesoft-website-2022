

<script>
    window._translations=@json($translations)
</script>