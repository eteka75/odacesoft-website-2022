<template>  
  <div>
  <nav class="navbar navbar-expand-lg navbar-light bg-white w-100">
    <div class="container">
      <a class="navbar-brand" id="logo-odacesoft" href="/"><img  src="../../../public/storage/images/logo-odacesoft-black-mini.png" alt="Odacesoft"  /></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="./">Qui somme nous ?</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.html"></a>
          </li>
          <li class="nav-item dropdown active">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Nos services
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="pages-landing.html">Pour les entrepreuneurs  </a>
              <a class="dropdown-item" href="pages-dashboard.html">Pour les particuliers</a>
              <a class="dropdown-item" href="pages-general.html">Autres</a>
            </div>
          </li>
          <!--li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Témoignanges
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="components-bootstrap.html">Bootstrap</a>
              <a class="dropdown-item" href="components-robust.html">Robust</a>
            </div>
          </li-->
          <li class="nav-item">
            <a class="nav-link" href="index.html">Nos projets</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.html">Nous contacter</a>
          </li>
          
        </ul>
        <a class="btn btn-primary btn-sm" href="https://themes.getbootstrap.com/product/robust-ui-kit-dashboard-landing/" target="_blank"><i class="fa fa-user"></i> Nous rejoindre</a>
      </div>
    </div>
  </nav>
  <div class="bg-danger text-white py-6" >
    <div class="container">
      <div class="row">
     
      
       <div class="col-md-6">
      <h6 class="h6 text-white">Notre objectif</h6>
        <h2 class="h1">
          Donner vie à vos rêves dans le domaine Digital
        </h2>
        <p>
          Vous pouvez tirer meilleur profit de l'utilisation des outils digitaux pour concrétiser
          vos projets, pour acroitre votre chiffre d'affaire ou pour apprendre une nouvelle compétence.
        </p>
        <div class="py-3">
          <a class="btn btn-white rounded-sm" href="">En savoir plus</a>
        </div>
      </div>
      <div class="col-md-6">

      </div>
    </div>
    
  </div>
</div>
  <div class="py-6">
  <div class="container">
    <div class="row">
      <div class="col-md-4  text-center">
         <a  href="/"><img  src="../../../public/storage/images/1.svg" alt="Sites Web"  class="w-80" /></a>     
        <h4 class="h6 font-weight-bold mt-2">Sites Web et d'Applications</h4>
        <p class="text-sm">Nous développons pour vous vos sites Web, applications Web et mobiles, applications Web et mobiles, applications Web et mobiles, ...  </p>
        <a href="#">En savoir plus</a>
      </div>
      <div class="col-md-4 text-center">
        <a  href="/"><img  src="../../../public/storage/images/2.svg" alt="Sites Web"  class="w-80" /></a>
        <h4 class="h6 font-weight-bold  mt-2">Communication et Marketing Digital</h4>
        <p class="text-sm">Pour donner plus d'impacts, nous mettons concevons pour des visuels de qualité suivi d'un plan de communication adapté à vos besoins.  </p>
      </div>
      <div class="col-md-4  text-center">
        <a  href="/"><img  src="../../../public/storage/images/3.svg" alt="Sites Web"  class="w-80" /></a>
        <h4 class="h6 font-weight-bold  mt-2">Expertise et Formation</h4>
      </div>
      <div class="col-md-4  text-center">
      
        <h4 class="text-secondary h6 font-weight-bold">Expertise et Formation</h4>
      </div>
      
      <div class="col-md-4  text-center">
      
        <h4 class="text-secondary h6 font-weight-bold">Expertise et Formation</h4>
      </div>

      <div class="col-md-4  text-center">
      
        <h4 class="text-secondary h6 font-weight-bold">Expertise et Formation</h4>
      </div>
    </div>
  </div>
  </div>
  <div class="intro py-8 bg-primary position-relative text-white">
    <div class="bg-overlay-primary">
      <img src="/storage/img/photos/8.jpg" class="img-fluid img-cover" alt="Robust UI Kit" />
    </div>
    <div class="intro-content mt-5">
      <div class="container">
        <div class="row">
          <div class="col-md-6 align-self-center">
            <h1 class="display-4 mb-3">Impress your clients,<br /> surprise your team</h1>
            <p class="lead mb-4">Robust is a premium theme built with Bootstrap. The theme is fully customizable & can be used for any type of application.</p>
          </div><!-- /.col-md-6 -->
          <div class="col-md-5 ml-auto">
            <div class="card">
              <div class="card-body text-dark">
                <form>
                  <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" placeholder="Enter your email">
                  </div>
                  <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" placeholder="Enter your password">
                  </div>
                  <div class="form-group">
                    <label for="password-repeat">Repeat password</label>
                    <input type="password" class="form-control" id="password-repeat" placeholder="Repeat your password">
                  </div>
                  <button type="submit" class="btn btn-success btn-block btn-lg mb-2">Sign up</button>
                  <div class="text-center">
                    Already have an account? <a href="#">Sign in</a>
                  </div>
                </form>
              </div>
            </div>
          </div><!-- /.col-md-6 -->
        </div>
      </div>
    </div>
  </div>

  <main class="main" role="main">
    <div class="bg-white py-7">
      <div class="container">
        <div class="row">
          <div class="col-md-10 mx-auto">
            <div class="row">
              <div class="col-md-4 ml-auto">
                <h2>Creative & flexible Bootstrap UI Kit</h2>
              </div>
              <div class="col-md-6 mr-auto">
                <p class="lead text-dark">
                  Robust includes various demo pages for building your custom app, blog or landing page. All code is handwritten, all our components are optimized for desktop, tablet and mobile.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="row mt-5">
          <div class="col-md-4">
            <div class="media">
              <div class="icon mr-3">
                <i class="far fa-id-badge"></i>
              </div>
              <div class="media-body">
                <h4 class="h4">Bootstrap 4</h4>
                <p class="text-dark text-left">
                  With mobile, tablet & desktop support it doesn't matter what device you're using. Robust is responsive in all browsers.
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="media">
              <div class="icon mr-3">
                <i class="far fa-hand-scissors"></i>
              </div>
              <div class="media-body">
                <h4 class="h4">Mobile friendly</h4>
                <p class="text-dark text-left">
                  Robust works perfectly with: Chrome, Firefox, Safari, Opera and IE 10+. We're working hard to support them.
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="media">
              <div class="icon mr-3">
                <i class="far fa-comments"></i>
              </div>
              <div class="media-body">
                <h4 class="h4">Premium support</h4>
                <p class="text-dark text-left">
                  Robust is supported by specialists who provide quick and effective support. Usually an email reply takes &lt;24h.
                </p>
              </div>
            </div>
          </div>
        </div><!-- /.row -->
      </div>
    </div>

    <div class="py-6">
      <div class="container">
          <div class="row">
            <div class="col-md-10 mx-auto">
              <h1 class="h2 text-center">We have a plan for everyone</h1>
              <p class="lead text-center mb-4">Whether you're a business or an individual, 14-day trial no credit card required.</p>

              <div class="row justify-content-center mt-5 mb-4">
                <div class="col-auto">
                  <nav class="nav btn-group">
                    <a href="#monthly" class="btn btn-outline-primary active" data-toggle="tab">Monthly billing</a>
                    <a href="#annual" class="btn btn-outline-primary" data-toggle="tab">Annual billing</a>
                  </nav>
                </div>
              </div>

              <div class="tab-content">
                <div class="tab-pane fade show active" id="monthly">
                  <div class="row py-4 equal-height-cards">
                    <div class="col-md-4">
                      <div class="card text-center">
                        <div class="card-body d-flex flex-column">
                          <div class="mb-4">
                            <h5>Free</h5>
                            <span class="display-3">$0</span>
                          </div>
                          <h6>Includes:</h6>
                          <ul class="list-unstyled">
                            <li class="mb-2">
                              1 users
                            </li>
                            <li class="mb-2">
                              5 projects
                            </li>
                            <li class="mb-2">
                              5 GB storage
                            </li>
                          </ul>
                          <div class="mt-auto">
                            <a href="#" class="btn btn-lg btn-outline-secondary">Sign up</a>
                          </div>
                        </div>
                      </div><!-- /.card -->
                    </div>
                    <div class="col-md-4">
                      <div class="card text-center">
                        <div class="card-body d-flex flex-column">
                          <div class="mb-4">
                            <h5>Standard</h5>
                            <span class="display-3">$19</span>
                            <span>/mo</span>
                          </div>
                          <h6>Includes:</h6>
                          <ul class="list-unstyled">
                            <li class="mb-2">
                              5 users
                            </li>
                            <li class="mb-2">
                              50 projects
                            </li>
                            <li class="mb-2">
                              50 GB storage
                            </li>
                            <li class="mb-2">
                              Security policy
                            </li>
                            <li class="mb-2">
                              Weekly backups
                            </li>
                          </ul>
                          <div class="mt-auto">
                            <a href="#" class="btn btn-lg btn-success">Try it for free</a>
                          </div>
                        </div>
                      </div><!-- /.card -->
                    </div>
                    <div class="col-md-4">
                      <div class="card text-center">
                        <div class="card-body d-flex flex-column">
                          <div class="mb-4">
                            <h5>Plus</h5>
                            <span class="display-3">$39</span>
                            <span>/mo</span>
                          </div>
                          <h6>Includes:</h6>
                          <ul class="list-unstyled">
                            <li class="mb-2">
                              Unlimited users
                            </li>
                            <li class="mb-2">
                              Unlimited projects
                            </li>
                            <li class="mb-2">
                              250 GB storage
                            </li>
                            <li class="mb-2">
                              Priority support
                            </li>
                            <li class="mb-2">
                              Security policy
                            </li>
                            <li class="mb-2">
                              Daily backups
                            </li>
                            <li class="mb-2">
                              Custom CSS
                            </li>
                          </ul>
                          <div class="mt-auto">
                            <a href="#" class="btn btn-lg btn-outline-secondary">Try it for free</a>
                          </div>
                        </div>
                      </div><!-- /.card -->
                    </div>
                  </div><!-- /.row -->
                </div><!-- /.tab-pane -->
                <div class="tab-pane fade" id="annual">
                  <div class="row py-4 equal-height-cards">
                    <div class="col-md-4">
                      <div class="card text-center">
                        <div class="card-body d-flex flex-column">
                          <div class="mb-4">
                            <h5>Free</h5>
                            <span class="display-3">$0</span>
                          </div>
                          <h6>Includes:</h6>
                          <ul class="list-unstyled">
                            <li class="mb-2">
                              1 users
                            </li>
                            <li class="mb-2">
                              5 projects
                            </li>
                            <li class="mb-2">
                              5 GB storage
                            </li>
                          </ul>
                          <div class="mt-auto">
                            <a href="#" class="btn btn-lg btn-outline-secondary">Sign up</a>
                          </div>
                        </div>
                      </div><!-- /.card -->
                    </div>
                    <div class="col-md-4">
                      <div class="card text-center">
                        <div class="card-body d-flex flex-column">
                          <div class="mb-4">
                            <h5>Standard</h5>
                            <span class="display-3">$199</span>
                            <span class="text-small4">/mo</span>
                          </div>
                          <h6>Includes:</h6>
                          <ul class="list-unstyled">
                            <li class="mb-2">
                              5 users
                            </li>
                            <li class="mb-2">
                              50 projects
                            </li>
                            <li class="mb-2">
                              50 GB storage
                            </li>
                            <li class="mb-2">
                              Security policy
                            </li>
                            <li class="mb-2">
                              Weekly backups
                            </li>
                          </ul>
                          <div class="mt-auto">
                            <a href="#" class="btn btn-lg btn-success">Try it for free</a>
                          </div>
                        </div>
                      </div><!-- /.card -->
                    </div>
                    <div class="col-md-4">
                      <div class="card text-center">
                        <div class="card-body d-flex flex-column">
                          <div class="mb-4">
                            <h5>Plus</h5>
                            <span class="display-3">$399</span>
                            <span>/mo</span>
                          </div>
                          <h6>Includes:</h6>
                          <ul class="list-unstyled">
                            <li class="mb-2">
                              Unlimited users
                            </li>
                            <li class="mb-2">
                              Unlimited projects
                            </li>
                            <li class="mb-2">
                              250 GB storage
                            </li>
                            <li class="mb-2">
                              Priority support
                            </li>
                            <li class="mb-2">
                              Security policy
                            </li>
                            <li class="mb-2">
                              Daily backups
                            </li>
                            <li class="mb-2">
                              Custom CSS
                            </li>
                          </ul>
                          <div class="mt-auto">
                            <a href="#" class="btn btn-lg btn-outline-secondary">Try it for free</a>
                          </div>
                        </div>
                      </div><!-- /.card -->
                    </div>
                  </div><!-- /.row -->
                </div><!-- /.tab-pane -->
              </div>
            </div>
          </div><!-- /.row -->
        </div>
    </div>

    <div class="py-6 bg-white">
      <div class="container">

        <div class="row mb-6">
          <div class="col-md-3 ml-auto">
            <h2>Features included in every plan</h2>
          </div>
          <div class="col-md-5 mr-auto">
            <p class="lead text-dark">
              Robust is a theme built with Bootstrap 4, the popular UI framework. The theme is responsive and can be used for any type of web app.
            </p>
          </div>
        </div>

        <div class="row mt-5">
          <div class="col-md-4">
            <div class="media">
              <div class="icon mr-3">
                <i class="far fa-id-badge"></i>
              </div>
              <div class="media-body">
                <h4 class="h4">Responsive</h4>
                <p class="text-dark text-left">
                  With mobile, tablet & desktop support it doesn't matter what device you're using. Robust is responsive in all browsers.
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="media">
              <div class="icon mr-3 bg-warning">
                <i class="far fa-hand-scissors"></i>
              </div>
              <div class="media-body">
                <h4 class="h4">Customizable</h4>
                <p class="text-dark text-left">
                  You don't need to be an expert to customize Robust. Our code is very readable and well documented.
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="media">
              <div class="icon mr-3 bg-danger">
                <i class="far fa-comments"></i>
              </div>
              <div class="media-body">
                <h4 class="h4">Quick support</h4>
                <p class="text-dark text-left">
                  Robust is supported by specialists who provide quick and effective support. Usually an email reply takes &lt;24h.
                </p>
              </div>
            </div>
          </div>
        </div><!-- /.row -->

        <div class="row mt-5">
          <div class="col-md-4">
            <div class="media">
              <div class="icon mr-3 bg-success">
                <i class="far fa-clone"></i>
              </div>
              <div class="media-body">
                <h4 class="h4">Cross browser</h4>
                <p class="text-dark text-left">
                  Robust works perfectly with: Chrome, Firefox, Safari, Opera and IE 10+. We're working hard to support them.
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="media">
              <div class="icon mr-3 bg-purple">
                <i class="far fa-gem"></i>
              </div>
              <div class="media-body">
                <h4 class="h4">Clean code</h4>
                <p class="text-dark text-left">
                  We strictly followed Bootstrap's guidelines to make your integration as easy as possible. All code is handwritten.
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="media">
              <div class="icon mr-3">
                <i class="far fa-arrow-alt-circle-down"></i>
              </div>
              <div class="media-body">
                <h4 class="h4">Free updates</h4>
                <p class="text-dark text-left">
                  From time to time you'll receive an update containing new components, improvements and bugfixes.
                </p>
              </div>
            </div>
          </div>
        </div><!-- /.row -->
      </div>
    </div>

    <div class="py-6 bg-light">
      <div class="container">
        <div class="text-center mb-5">
          <h4>What others are saying</h4>
        </div>
      </div>
      <div data-flickity='{ "prevNextButtons": false, "wrapAround": true}'>
        <div class="carousel-cell">
          <div class="container">
            <div class="row">
              <div class="col-md-10 mx-auto">
                <div class="media">
                  <img src="/storage/img/avatars/1.jpg" alt="Avatar" class="img-fluid rounded-circle mr-4" style="max-width:128px;" />
                  <div class="media-body">
                    <blockquote class="h4 font-weight-normal">
                      “I can only recommend both this theme and the competent developer behind it to other people. Quick & helpful support! ”
                    </blockquote>
                    <span>Jane Roe</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-cell">
          <div class="container">
            <div class="row">
              <div class="col-md-10 mx-auto">
                <div class="media">
                  <img src="/storage/img/avatars/2.jpg" alt="Avatar" class="img-fluid rounded-circle mr-4" style="max-width:128px;" />
                  <div class="media-body">
                    <blockquote class="h4 font-weight-normal">
                      “I can only recommend both this theme and the competent developer behind it to other people. Quick & helpful support! ”
                    </blockquote>
                    <span>John Roe</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-cell">
          <div class="container">
            <div class="row">
              <div class="col-md-10 mx-auto">
                <div class="media">
                  <img src="/storage/img/avatars/3.jpg" alt="Avatar" class="img-fluid rounded-circle mr-4" style="max-width:128px;" />
                  <div class="media-body">
                    <blockquote class="h4 font-weight-normal">
                      “I can only recommend both this theme and the competent developer behind it to other people. Quick & helpful support! ”
                    </blockquote>
                    <span>Jane Roe</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="py-6 bg-danger text-white">
      <div class="container">
        <div class="row">
          <div class="col-md-10 mx-auto">
            <div class="row">
              <div class="col-md-4 ml-auto">
                <h2>Who we are<br /> working with</h2>
              </div>
              <div class="col-md-6 mr-auto">
                <p class="lead text-light">
                  Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan.
                </p>
              </div>
            </div>
            <div class="row align-items-center my-md-4 text-center">
              <div class="col">
                <i class="fab fa-4x fa-microsoft"></i>
              </div>
              <div class="col">
                <i class="fab fa-4x fa-github"></i>
              </div>
              <div class="col">
                <i class="fab fa-4x fa-ebay"></i>
              </div>
              <div class="col">
                <i class="fab fa-4x fa-apple"></i>
              </div>
              <div class="col">
                <i class="fab fa-4x fa-amazon"></i>
              </div>
              <div class="col">
                <i class="fab fa-4x fa-stripe"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <footer role="contentinfo" class="py-6 lh-1 bg-white">
    <div class="container">
      <div class="row">
        <div class="col-md-2">
          <h4 class="h4 mb-4">Robust.</h4>
        </div>
        <div class="col-md-10">
          <div class="row">
            <div class="col-md-3 col-sm-6">
              <h4 class="h6">Address</h4>
              <address>
    						<ul class="list-unstyled">
    							<li>
                    City Hall<br>
    								212  Street<br>
    								Lawoma<br>
    								735<br>
    							</li>
    						</ul>
    					</address>
            </div>
            <div class="col-md-3 col-sm-6">
              <h4 class="h6">Popular Services</h4>
              <ul class="list-unstyled">
                <li><a href="#">Payment Center</a></li>
                <li><a href="#">Contact Directory</a></li>
                <li><a href="#">Forms</a></li>
                <li><a href="#">News and Updates</a></li>
                <li><a href="#">FAQs</a></li>
              </ul>
            </div>
            <div class="col-md-3 col-sm-6">
              <h4 class="h6">Website Information</h4>
              <ul class="list-unstyled">
                <li><a href="#">Website Tutorial</a></li>
                <li><a href="#">Accessibility</a></li>
                <li><a href="#">Disclaimer</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">FAQs</a></li>
                <li><a href="#">Webmaster</a></li>
              </ul>
            </div>
            <div class="col-md-3 col-sm-6">
              <h4 class="h6">Company</h4>
              <ul class="list-unstyled">
                <li><a href="#">Our team</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="https://themes.getbootstrap.com/product/robust-ui-kit-dashboard-landing/" target="_blank">Purchase</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-12 text-center text-sm">
          <p class="mb-0">&copy; 2021 - <a href="index.html">Robust UI Kit</a>.</p>
        </div>
      </div>
    </div>
  </footer>

    <!--div class="container-fluid fixed-top p-4">
      <div class="col-12">
        <div v-if="canLogin" class="d-flex justify-content-end">
          <div>
            <inertia-link v-if="$page.props.user" href="/dashboard" class="text-muted">
              Dashboard
            </inertia-link>

            <template v-else>
              <inertia-link :href="route('login')" class="text-muted">
                Log in
              </inertia-link>

              <inertia-link v-if="canRegister" :href="route('register')" class="ml-4 text-muted">
                Register
              </inertia-link>
            </template>
          </div>
        </div>
      </div>
    </div-->

    <div class="container-fluid my-5 pt-5 px-5">
      <div class="row justify-content-center px-4">
        <div class="col-md-12 col-lg-9">
          <svg viewBox="0 0 651 192" fill="none" xmlns="http://www.w3.org/2000/svg" class="my-4" style="width: 271px">
            <g clip-path="url(#clip0)" fill="#EF3B2D">
              <path d="M248.032 44.676h-16.466v100.23h47.394v-14.748h-30.928V44.676zM337.091 87.202c-2.101-3.341-5.083-5.965-8.949-7.875-3.865-1.909-7.756-2.864-11.669-2.864-5.062 0-9.69.931-13.89 2.792-4.201 1.861-7.804 4.417-10.811 7.661-3.007 3.246-5.347 6.993-7.016 11.239-1.672 4.249-2.506 8.713-2.506 13.389 0 4.774.834 9.26 2.506 13.459 1.669 4.202 4.009 7.925 7.016 11.169 3.007 3.246 6.609 5.799 10.811 7.66 4.199 1.861 8.828 2.792 13.89 2.792 3.913 0 7.804-.955 11.669-2.863 3.866-1.908 6.849-4.533 8.949-7.875v9.021h15.607V78.182h-15.607v9.02zm-1.431 32.503c-.955 2.578-2.291 4.821-4.009 6.73-1.719 1.91-3.795 3.437-6.229 4.582-2.435 1.146-5.133 1.718-8.091 1.718-2.96 0-5.633-.572-8.019-1.718-2.387-1.146-4.438-2.672-6.156-4.582-1.719-1.909-3.032-4.152-3.938-6.73-.909-2.577-1.36-5.298-1.36-8.161 0-2.864.451-5.585 1.36-8.162.905-2.577 2.219-4.819 3.938-6.729 1.718-1.908 3.77-3.437 6.156-4.582 2.386-1.146 5.059-1.718 8.019-1.718 2.958 0 5.656.572 8.091 1.718 2.434 1.146 4.51 2.674 6.229 4.582 1.718 1.91 3.054 4.152 4.009 6.729.953 2.577 1.432 5.298 1.432 8.162-.001 2.863-.479 5.584-1.432 8.161zM463.954 87.202c-2.101-3.341-5.083-5.965-8.949-7.875-3.865-1.909-7.756-2.864-11.669-2.864-5.062 0-9.69.931-13.89 2.792-4.201 1.861-7.804 4.417-10.811 7.661-3.007 3.246-5.347 6.993-7.016 11.239-1.672 4.249-2.506 8.713-2.506 13.389 0 4.774.834 9.26 2.506 13.459 1.669 4.202 4.009 7.925 7.016 11.169 3.007 3.246 6.609 5.799 10.811 7.66 4.199 1.861 8.828 2.792 13.89 2.792 3.913 0 7.804-.955 11.669-2.863 3.866-1.908 6.849-4.533 8.949-7.875v9.021h15.607V78.182h-15.607v9.02zm-1.432 32.503c-.955 2.578-2.291 4.821-4.009 6.73-1.719 1.91-3.795 3.437-6.229 4.582-2.435 1.146-5.133 1.718-8.091 1.718-2.96 0-5.633-.572-8.019-1.718-2.387-1.146-4.438-2.672-6.156-4.582-1.719-1.909-3.032-4.152-3.938-6.73-.909-2.577-1.36-5.298-1.36-8.161 0-2.864.451-5.585 1.36-8.162.905-2.577 2.219-4.819 3.938-6.729 1.718-1.908 3.77-3.437 6.156-4.582 2.386-1.146 5.059-1.718 8.019-1.718 2.958 0 5.656.572 8.091 1.718 2.434 1.146 4.51 2.674 6.229 4.582 1.718 1.91 3.054 4.152 4.009 6.729.953 2.577 1.432 5.298 1.432 8.162 0 2.863-.479 5.584-1.432 8.161zM650.772 44.676h-15.606v100.23h15.606V44.676zM365.013 144.906h15.607V93.538h26.776V78.182h-42.383v66.724zM542.133 78.182l-19.616 51.096-19.616-51.096h-15.808l25.617 66.724h19.614l25.617-66.724h-15.808zM591.98 76.466c-19.112 0-34.239 15.706-34.239 35.079 0 21.416 14.641 35.079 36.239 35.079 12.088 0 19.806-4.622 29.234-14.688l-10.544-8.158c-.006.008-7.958 10.449-19.832 10.449-13.802 0-19.612-11.127-19.612-16.884h51.777c2.72-22.043-11.772-40.877-33.023-40.877zm-18.713 29.28c.12-1.284 1.917-16.884 18.589-16.884 16.671 0 18.697 15.598 18.813 16.884h-37.402zM184.068 43.892c-.024-.088-.073-.165-.104-.25-.058-.157-.108-.316-.191-.46-.056-.097-.137-.176-.203-.265-.087-.117-.161-.242-.265-.345-.085-.086-.194-.148-.29-.223-.109-.085-.206-.182-.327-.252l-.002-.001-.002-.002-35.648-20.524a2.971 2.971 0 00-2.964 0l-35.647 20.522-.002.002-.002.001c-.121.07-.219.167-.327.252-.096.075-.205.138-.29.223-.103.103-.178.228-.265.345-.066.089-.147.169-.203.265-.083.144-.133.304-.191.46-.031.085-.08.162-.104.25-.067.249-.103.51-.103.776v38.979l-29.706 17.103V24.493a3 3 0 00-.103-.776c-.024-.088-.073-.165-.104-.25-.058-.157-.108-.316-.191-.46-.056-.097-.137-.176-.203-.265-.087-.117-.161-.242-.265-.345-.085-.086-.194-.148-.29-.223-.109-.085-.206-.182-.327-.252l-.002-.001-.002-.002L40.098 1.396a2.971 2.971 0 00-2.964 0L1.487 21.919l-.002.002-.002.001c-.121.07-.219.167-.327.252-.096.075-.205.138-.29.223-.103.103-.178.228-.265.345-.066.089-.147.169-.203.265-.083.144-.133.304-.191.46-.031.085-.08.162-.104.25-.067.249-.103.51-.103.776v122.09c0 1.063.568 2.044 1.489 2.575l71.293 41.045c.156.089.324.143.49.202.078.028.15.074.23.095a2.98 2.98 0 001.524 0c.069-.018.132-.059.2-.083.176-.061.354-.119.519-.214l71.293-41.045a2.971 2.971 0 001.489-2.575v-38.979l34.158-19.666a2.971 2.971 0 001.489-2.575V44.666a3.075 3.075 0 00-.106-.774zM74.255 143.167l-29.648-16.779 31.136-17.926.001-.001 34.164-19.669 29.674 17.084-21.772 12.428-43.555 24.863zm68.329-76.259v33.841l-12.475-7.182-17.231-9.92V49.806l12.475 7.182 17.231 9.92zm2.97-39.335l29.693 17.095-29.693 17.095-29.693-17.095 29.693-17.095zM54.06 114.089l-12.475 7.182V46.733l17.231-9.92 12.475-7.182v74.537l-17.231 9.921zM38.614 7.398l29.693 17.095-29.693 17.095L8.921 24.493 38.614 7.398zM5.938 29.632l12.475 7.182 17.231 9.92v79.676l.001.005-.001.006c0 .114.032.221.045.333.017.146.021.294.059.434l.002.007c.032.117.094.222.14.334.051.124.088.255.156.371a.036.036 0 00.004.009c.061.105.149.191.222.288.081.105.149.22.244.314l.008.01c.084.083.19.142.284.215.106.083.202.178.32.247l.013.005.011.008 34.139 19.321v34.175L5.939 144.867V29.632h-.001zm136.646 115.235l-65.352 37.625V148.31l48.399-27.628 16.953-9.677v33.862zm35.646-61.22l-29.706 17.102V66.908l17.231-9.92 12.475-7.182v33.841z"/>
            </g>
          </svg>

          <div class="card shadow-sm">
            <div class="row">
              <div class="col-md-6 pr-0">
                <div class="card-body border-right border-bottom p-3 h-100">
                  <div class="d-flex flex-row bd-highlight pt-2">
                    <div>
                      <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" class="text-muted" width="32"><path d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
                    </div>
                    <div class="pl-3">
                      <div class="mb-2">
                        <a href="https://laravel.com/docs" class="h5 font-weight-bolder text-dark">Documentation</a>
                      </div>
                      <p class="text-muted small">
                        Laravel has wonderful, thorough documentation covering every aspect of the framework. Whether you are new to the framework or have previous experience with Laravel, we recommend reading all of the documentation from beginning to end.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-6 pl-0">
                <div class="card-body border-bottom p-3 h-100">
                  <div class="d-flex flex-row bd-highlight pt-2">
                    <div>
                      <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" class="text-muted" width="32"><path d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h4.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path><path d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                    </div>
                    <div class="pl-3">
                      <div class="mb-2">
                        <a href="https://laracasts.com" class="h5 font-weight-bolder text-dark">Laracasts</a>
                      </div>
                      <p class="text-muted small">
                        Laracasts offers thousands of video tutorials on Laravel, PHP, and JavaScript development. Check them out, see for yourself, and massively level up your development skills in the process.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-6 pr-0">
                <div class="card-body border-right p-3 h-100">
                  <div class="d-flex flex-row bd-highlight pt-2">
                    <div>
                      <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" class="text-muted" width="32"><path d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z"></path></svg>
                    </div>
                    <div class="pl-3 text-sm">
                      <div class="mb-2">
                        <a href="https://laravel-news.com/" class="h5 font-weight-bolder text-dark">Laravel News</a>
                      </div>
                      <p class="text-muted small">
                        Laravel News is a community driven portal and newsletter aggregating all of the latest and most important news in the Laravel ecosystem, including new package releases and tutorials.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-6 pl-0">
                <div class="card-body p-3 h-100">
                  <div class="d-flex flex-row bd-highlight pt-2">
                    <div>
                      <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" class="text-muted" width="32"><path d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h4.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    </div>
                    <div class="pl-3">
                      <div class="mb-2">
                        <span class="h5 font-weight-bolder text-dark">Vibrant Ecosystem</span>
                      </div>
                      <p class="text-muted small">
                        Laravel's robust library of first-party tools and libraries, such as <a href="https://forge.laravel.com" class="text-muted">Forge</a>, <a href="https://vapor.laravel.com" class="text-muted">Vapor</a>, <a href="https://nova.laravel.com" class="text-muted">Nova</a>, and <a href="https://envoyer.io" class="text-muted">Envoyer</a> help you take your projects to the next level. Pair them with powerful open source libraries like <a href="https://laravel.com/docs/billing" class="text-muted">Cashier</a>, <a href="https://laravel.com/docs/dusk" class="text-muted">Dusk</a>, <a href="https://laravel.com/docs/broadcasting" class="text-muted">Echo</a>, <a href="https://laravel.com/docs/horizon" class="text-muted">Horizon</a>, <a href="https://laravel.com/docs/sanctum" class="text-muted">Sanctum</a>, <a href="https://laravel.com/docs/telescope" class="text-muted">Telescope</a>, and more.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="d-flex justify-content-between mt-3">
            <div class="text-sm text-muted">
              <div class="flex align-content-center">
                <svg fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor" class="text-muted" style="width: 18px">
                  <path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path>
                </svg>

                <a href="https://laravel.bigcartel.com" class="text-muted">
                  Shop
                </a>

                <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" class="ml-4 text-muted" style="width: 18px">
                  <path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
                </svg>

                <a href="https://github.com/sponsors/taylorotwell" class="text-muted">
                  Sponsor
                </a>
              </div>
            </div>

            <div class="text-sm text-muted">
              Laravel v{{ laravelVersion }} (PHP v{{ phpVersion }})
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>

<script>
export default {
  props: {
    canLogin: Boolean,
    canRegister: Boolean,
    laravelVersion: String,
    phpVersion: String,
  }
}
</script>
<style>

 
</style>
