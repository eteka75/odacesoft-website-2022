<template>
  <Header menu="Contacts" />
  <Head>
    <title>Nous contacter • Odacesoft</title>
    <meta
      head-key="description"
      name="description"
      content="Contactez nous par email, par Whatsapp, sur les réseaux socieux ou envoyez-nous un message."
    />
  </Head>
  <cover-layout>

    <div id="services-contact" >
      <div class="container max-w-screen-xl">
        <div class="row">
          <div class="col-md-12 text-center align-items-baseline col-xl-12">
            <div class="pt-6 pb-8 pt-xl-20 pb-xl-8">
              <h1
                class="
                  lh-tight
                  text-white
                  ls-tight
                  tb-shadow
                  display-5
                  mt-10
                  mb-1
                "
              >
                Contactez-nous !
              </h1>
              <p class="text-lg text-white px-lg-56 px-md-30 tb-shadow">
                Pour mieux réussir dans votre prochain projet, notre coup de
                main pourra changer positivement vos résultats.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <section class="wrapper bg-gray-100_ bg-translucent-dark border-bottom  wrapper-border">
			<div class="container py-14 py-md-16">
				<div class="row">
					<div class="col-xl-10 mx-auto">
						<div class="card shadow-lg">
							<div class="row gx-0">
								<div class="col-lg-6 align-self-stretch">
									<div class="map map-full overflow-hidden  rounded-sm rounded-lg-start">
                    <!--iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3936.680531454854!2d2.6318572147891373!3d9.361511993290659!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x10321115a5402d05%3A0x7ba8c3c5bc56de8d!2sOdacesoft!5e0!3m2!1sfr!2sbj!4v1649011129744!5m2!1sfr!2sbj"  style="width:100%; height: 100%; border:0" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe-->
                    <iframe src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d2023601.3831335008!2d1.0665892184446712!3d7.858763822215952!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e0!4m5!1s0x102354e509f894f7%3A0xc8fde921f89849f6!2zQ290b25vdSwgQsOpbmlu!3m2!1d6.3702928!2d2.3912362!4m5!1s0x10321115a5402d05%3A0x7ba8c3c5bc56de8d!2sOdacesoft%2C%20123%2C%20Parakou!3m2!1d9.361512!2d2.6340459!5e0!3m2!1sfr!2sbj!4v1649089666341!5m2!1sfr!2sbj"  style="width:100%; height: 100%; border:0" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
									</div>
									<!-- /.map -->
								</div>
								<!--/column -->
								<div class="col-lg-6">
									<div class="p-10 p-md-11 p-lg-14">
										<div class="d-flex flex-row">
											<div>
												<div class="icon text-muted fs-20 me-4 mt-n1"> <i class="fa fa fa-location text-sm"></i> </div>
											</div>
											<div class="align-self-start justify-content-start">
												<h5 class="mb-1">Address</h5>
												<address>Parakou-Bénin, Quartier Zongo 2. Dans la rue avant l'ex "Bar CLASSICO" en quittant le marché Zongo</address>
											</div>
										</div>
										<!--/div -->
										<div class="d-flex flex-row mt-5">
											<div>
												<div class="icon text-muted fs-20 me-4 mt-n1"> <i class="fa  transform rotate-90  text-sm fa-phone"></i> </div>
											</div>
											<div>
												<h5 class="mb-1">Téléphone</h5>
												<p>00 (229) 64 84 42 12 </p>
												<p>00 (229) 96 06 36 82</p>
											</div>
										</div>
										<!--/div -->
										<div class="d-flex flex-row mt-5">
											<div>
												<div class="icon text-muted fs-28 me-4 mt-n2"> <i class="fa text-sm  fa-envelope-open"></i> </div>
											</div>
											<div>
												<h5 class="mb-1">E-mail</h5>
												<p class="mb-0 text-sm text-dark"><a href="mailto:odacesoft@gmail.com" class="link-body  text-sm text-dark text-primary-hover">odacesoft@gmail.com</a></p>
												<p class="mb-0  text-sm text-dark"><a href="mailto:contact@odacesoft.com" class="link-body  text-sm text-dark  text-primary-hover">contact@odacesoft.com</a></p>
											</div>
										</div>
										<!--/div -->

									<!--/div -->
                                    <div class="d-flex flex-row mt-5">
                                        <div>
                                            <div class="icon text-muted fs-28 me-4 mt-n1"> <i class="fa text-sm  fa-share-alt"></i> </div>
                                        </div>
                                        <div>
                                            <h5 class="mb-1">Réseaux sociaux</h5>

                                            <span class="d-block text-sm">
                                                <a  target="_blanck"
                                                class="text-lg mx-2 text-primary"
                                                href="https://fb.me/Odacesoft"
                                                ><i class="fab fa-facebook" aria-hidden="true"></i
                                                ></a>
                                                <a
                                                target="_blanck"
                                                class="text-lg  mx-2 text-info"
                                                href="https://twitter.com/odacesoft"
                                                ><i class="fab  text-info-hover fa-twitter" aria-hidden="true"></i
                                                ></a>
                                                <a  target="_blanck"
                                                class="text-lg  mx-2 text-blue2"
                                                href="https://linkedin.com/company/odacesoft"
                                                ><i class="fab  text-danger-primary fa-linkedin" aria-hidden="true"></i
                                                ></a>
                                                <a  target="_blanck"
                                                class="text-lg mx-2  text-danger"
                                                href="https://www.youtube.com/channel/UC_A-w6yMj3cMtAVoeXifFBQ"
                                                ><i class="fab  text-danger-hover fa-youtube" aria-hidden="true"></i
                                                ></a>
                                            </span>
                                        </div>

                                    </div>
                                    <div class="d-flex flex-row mt-5">
                                            <!--button type="submit" class="btn btn-lg btn-primary"><i class="fa fa-comments"></i> Envoyer un message</button-->
                                        </div>
                                    </div>
								</div>
								<!--/column -->
							</div>
							<!--/.row -->
						</div>
						<!-- /.card -->
					</div>
					<!-- /column -->
				</div>
				<!-- /.row -->
			</div>
			<!-- /.container -->
		</section>
    <div class=" bg-surface-secondary__"  id="send-message">
    <div class="container-lg max-w-screen-xl">
      <div class="row">
        <div class="col-md-6 py-4 py-xl-12">
            <img src="/storage/assets/web/image/msg-contact.png" class="img-responsive" width="" height="" alt="Laissez-nous unmessage">
        </div>
        <div class="col-md-6 shadow-4 border-start ">
          <div class=" pt-4 pt-xl-10">
            <div
              class="group-cards group-profile-cards component-card-profile-1"
              id="component-shot"
            >
            <form method="post" @submit.prevent="contacter">
              <div class="cardmx-autoshadow-2border-2border-primary mb-10">
                <div class="card-body">

                  <div class=' '>
                    <h3>Envoyez un message</h3>

                    <div class="mb-3 mt-4 ">
                      <label for="nom" class="form-label text-muted text-xs">Nom et prénom(s) *</label>
                      <input required type="text" v-model="form.nom" placeholder="NOM Prénoms"  :disabled="form.processing"  :class="[$page.props.errors.nom ?'is-invalid':'is-valid_']"  class="form-control col-md-6" id="nom" aria-describedby="nomHelp">

                        <div v-if="$page.props.errors.nom"
                                    class="form-text text-danger py-1 text-xs">
                                    {{ $page.props.errors.nom }}
                        </div>
                    </div>
                    <div class="row ">

                      <div class="mb-3 col-sm-12  col-md-6  ">
                        <label for="exampleInputEmail1" class="form-label text-muted text-xs">Email* </label>
                        <input  required type="text" v-model="form.email"  placeholder="votremail@domaine.com"  :disabled="form.processing"  :class="[$page.props.errors.email ?'is-invalid':'is-valid_']" class="form-control col-md-6" id="exampleInputEmail1" aria-describedby="emailHelp">
                        <div v-if="$page.props.errors.email"
                                    class="form-text text-danger py-1 text-xs">
                                    {{ $page.props.errors.email }}
                        </div>
                      </div>
                      <div class="mb-3 col-sm-12  col-md-6">
                        <label for="tel" class="form-label text-muted text-xs">Téléphone: </label>
                        <input type="tel" v-model="form.tel"  placeholder="+229 96 40 40 40" :disabled="form.processing"  :class="[$page.props.errors.tel ?'is-invalid':'is-valid_']"  class="form-control col-md-6" id="tel" aria-describedby="telHelp">
                        <div v-if="$page.props.errors.tel"
                                    class="form-text text-danger py-1 text-xs">
                                    {{ $page.props.errors.tel }}
                        </div>
                      </div>
                    </div>
                    <div class="mb-3 ">
                      <label for="exampleInputPassword1" class="form-label text-muted text-xs">Objet *</label>
                      <select required  :disabled="form.processing"  :class="[$page.props.errors.objet ?'is-invalid':'is-valid_']" v-model="form.objet" class="form-select">
                        <option value="PRISE-DE-CONTACT">Prise de contact</option>
                        <option value="RENSEIGNEMENT">Demande de renseignement</option>
                        <option value="COMMANDE">Commander un service</option>
                        <option value="PARTENAIRIAT">Demande de partenariat</option>
                        <option value="SOUTIENT">Encouragement ou soutient </option>
                      </select>
                      <div v-if="$page.props.errors.objet"
                                    class="form-text text-danger py-1 text-xs">
                                    {{ $page.props.errors.objet }}
                        </div>
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputPassword1" class="form-label text-muted text-xs">Message *</label>
                      <textarea required type="password" v-model="form.message"  :class="[$page.props.errors.message ?'is-invalid':'is-valid_']" rows="5" class="form-control" placeholder="Rédigez votre préocupation ici..." id="exampleInputPassword1"></textarea>
                    <div v-if="$page.props.errors.message"
                                    class="form-text text-danger py-1 text-xs">
                                    {{ $page.props.errors.message }}
                        </div>
                    </div>
                    <div class="form-group mb-5">
                      <div class="form-check form-switch">
                        <input
                            value="1"
                            id="remember_me"
                            class="form-check-input" name="remember"
                        v-model="form.notification"
                        :disabled="form.processing"  :class="[$page.props.errors.exp ?'is-invalid':'is-valid_']"
                            checked
                            type="checkbox"
                        />
                        <label class="form-check-label" for="remember_me"
                            >Recevoir de nouvelles offres par email</label
                        >
                </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Envoyer mon message -></button>

                  </div>
                </div>
              </div>
            </form>

            </div>
          </div>
        </div>
      </div>
    </div>
    </div>

  </cover-layout>
</template>

<script>
import { Head } from "@inertiajs/inertia-vue3";
import Header from "@/Components/Header";
import Notification from "@/Components/Notification";
import Footer from "@/Components/Footer";
import CoverLayout from "@/Layouts/CoverLayout";

export default {
  components: {
    Header,
    Notification,
    Footer,
    CoverLayout,
  },
data(){
    return{
        titre: "Envoie de mesage",
    showbloc:false,
    form: this.$inertia.form({
    nom: null,
    email : null,
    tel: null,
    message: null,
    objet: 'PRISE-DE-CONTACT',
    notification: false,
    active: false,
    })
    };
},
  methods: {
      contacter:function(){
        this.$inertia.post(this.route("contacter"), this.form, {
          forceFormData: true,
        });
    }
  }
};
</script>
<style scoped>

  #services-contact{
    background:url('../../../../public/storage/assets/web/image/fond-contact-clients.jpg') #111 no-repeat;
    background-position: 0% 0%;
  background-size: 110% auto;
 }
@media screen and (min-width:800px) {
  #services-contact{
  min-height: 350px;
  }
}
#carte{height:750px;margin-top:-325px}
.align-self-stretch {
    align-self: stretch !important;
}
.map.map-full {
    height: 100%;
    min-height: 15rem;

    border-top-left-radius: 0.4rem !important;
    border-top-right-radius: 0.4rem !important;
}
</style>
