<template>
<Header menu="Projets"/>
  <Head>
    <title>Nos projets • Odacesoft</title>
    <meta head-key="description" name="description" content="Découvrez nos différents partenaires qui nous aides dans l'atteinte de nos objectifs." />
  </Head>
  <cover-layout>
    <div  id="bg-projets">
    <div  class="container-lg max-w-screen-xl">
     <div class="row">
          <div class="col-md-12 text-center align-items-baseline col-xl-12">
            <div class="pt-6 pb-8  pt-xl-20 pb-xl-8">
              <h1 class="lh-tight text-white ls-tight tb-shadow display-5 mt-16 mb-1">
             Nos projets
              </h1>
              <p class="text-lg  text-white px-lg-56 px-md-30 tb-shadow">
                Pour mieux réussir dans votre prochain projet, notre coup de main pourra changer positivement vos résultats. 
              </p>
            </div>
          </div>
          <div class="col-md-6 col-xl-6">
            <!--img src="../../../../public/storage/assets/web/image/s-particuliers.png" alt="Services aux particuliers"-->
          </div>
        </div>
    </div>
        <div class="container pt-10 pt-md-14">
            <div class="row">
                <div class="col-md-8 col-lg-7 col-xl-6 col-xxl-5">
                    <h1 class="display-1 mb-3">Projects</h1>
                    <p class="lead fs-lg pe-lg-15 pe-xxl-12">Check out some of our awesome projects with creative ideas and great design.</p>
                </div>
                <!-- /column -->
            </div>
            <!-- /.row -->
        </div>

        <section class="wrapper bg-light">
			<div class="container py-14 py-md-16">
				<div class="grid grid-view projects-masonry">
					<div class="isotope-filter filter mb-10">
						<p>Filter:</p>
						<ul>
							<li><a class="filter-item active" data-filter="*">All</a></li>
							<li><a class="filter-item" data-filter=".concept">Concept</a></li>
							<li><a class="filter-item" data-filter=".product">Product</a></li>
							<li><a class="filter-item" data-filter=".workshop">Workshop</a></li>
							<li><a class="filter-item" data-filter=".still-life">Still Life</a></li>
						</ul>
					</div>
					<div class="row gx-md-8 gy-10 gy-md-13 isotope">
						<div class="project item col-md-6 col-xl-4 product">
							<figure class="lift rounded mb-6"><a href="single-project.html"> <img src="src/img/photos/cs16.jpg" alt=""></a></figure>
							<div class="project-details d-flex justify-content-center flex-column">
								<div class="post-header">
									<div class="post-category text-line mb-3 text-purple">Cosmetic</div>
									<h2 class="post-title h3">Cras Fermentum Sem</h2>
								</div>
								<!-- /.post-header -->
							</div>
							<!-- /.project-details -->
						</div>
						<!-- /.project -->
						<div class="project item col-md-6 col-xl-4 workshop">
							<figure class="lift rounded mb-6"><a href="single-project2.html"> <img src="src/img/photos/cs17.jpg" alt=""></a></figure>
							<div class="project-details d-flex justify-content-center flex-column">
								<div class="post-header">
									<div class="post-category text-line mb-3 text-leaf">Coffee</div>
									<h2 class="post-title h3">Mollis Ipsum Mattis</h2>
								</div>
								<!-- /.post-header -->
							</div>
							<!-- /.project-details -->
						</div>
						<!-- /.project -->
						<div class="project item col-md-6 col-xl-4 still-life">
							<figure class="lift rounded mb-6"><a href="single-project3.html"> <img src="src/img/photos/cs18.jpg" alt=""></a></figure>
							<div class="project-details d-flex justify-content-center flex-column">
								<div class="post-header">
									<div class="post-category text-line mb-3 text-violet">Still Life</div>
									<h2 class="post-title h3">Ipsum Ultricies Cursus</h2>
								</div>
								<!-- /.post-header -->
							</div>
							<!-- /.project-details -->
						</div>
						<!-- /.project -->
						<div class="project item col-md-6 col-xl-4 product">
							<figure class="lift rounded mb-6"><a href="single-project2.html"> <img src="src/img/photos/cs20.jpg" alt=""></a></figure>
							<div class="project-details d-flex justify-content-center flex-column">
								<div class="post-header">
									<div class="post-category text-line mb-3 text-orange">Product</div>
									<h2 class="post-title h3">Inceptos Euismod Egestas</h2>
								</div>
								<!-- /.post-header -->
							</div>
							<!-- /.project-details -->
						</div>
						<!-- /.project -->
						<div class="project item col-md-6 col-xl-4 product">
							<figure class="lift rounded mb-6"><a href="single-project.html"> <img src="src/img/photos/cs19.jpg" alt=""></a></figure>
							<div class="project-details d-flex justify-content-center flex-column">
								<div class="post-header">
									<div class="post-category text-line mb-3 text-yellow">Product</div>
									<h2 class="post-title h3">Sollicitudin Ornare Porta</h2>
								</div>
								<!-- /.post-header -->
							</div>
							<!-- /.project-details -->
						</div>
						<!-- /.project -->
						<div class="project item col-md-6 col-xl-4 workshop">
							<figure class="lift rounded mb-6"><a href="single-project3.html"> <img src="src/img/photos/cs21.jpg" alt=""></a></figure>
							<div class="project-details d-flex justify-content-center flex-column">
								<div class="post-header">
									<div class="post-category text-line mb-3 text-green">Workshop</div>
									<h2 class="post-title h3">Ipsum Mollis Vulputate</h2>
								</div>
								<!-- /.post-header -->
							</div>
							<!-- /.project-details -->
						</div>
						<!-- /.project -->
						<div class="project item col-md-6 col-xl-4 concept">
							<figure class="lift rounded mb-6"><a href="single-project2.html"> <img src="src/img/photos/cs22.jpg" alt=""></a></figure>
							<div class="project-details d-flex justify-content-center flex-column">
								<div class="post-header">
									<div class="post-category text-line mb-3 text-red">Concept</div>
									<h2 class="post-title h3">Porta Ornare Cras</h2>
								</div>
								<!-- /.post-header -->
							</div>
							<!-- /.project-details -->
						</div>
						<!-- /.project -->
						<div class="project item col-md-6 col-xl-4 concept still-life">
							<figure class="lift rounded mb-6"><a href="single-project.html"> <img src="src/img/photos/cs23.jpg" alt=""></a></figure>
							<div class="project-details d-flex justify-content-center flex-column">
								<div class="post-header">
									<div class="post-category text-line mb-3 text-aqua">Concept</div>
									<h2 class="post-title h3">Vulputate Sollicitudin</h2>
								</div>
								<!-- /.post-header -->
							</div>
							<!-- /.project-details -->
						</div>
						<!-- /.project -->
						<div class="project item col-md-6 col-xl-4 product">
							<figure class="lift rounded mb-6"><a href="single-project3.html"> <img src="src/img/photos/cs24.jpg" alt=""></a></figure>
							<div class="project-details d-flex justify-content-center flex-column">
								<div class="post-header">
									<div class="post-category text-line mb-3 text-purple">Product</div>
									<h2 class="post-title h3">Magna Tristique Inceptos</h2>
								</div>
								<!-- /.post-header -->
							</div>
							<!-- /.project-details -->
						</div>
						<!-- /.project -->
					</div>
					<!-- /.row -->
				</div>
				<!-- /.grid -->
			</div>
			<!-- /.container -->
		</section>
    </div>
  </cover-layout>
</template>
  
<script>
import { Head } from '@inertiajs/inertia-vue3'
import Header from "@/Components/Header";
import Notification from "@/Components/Notification";
import Footer from "@/Components/Footer";
import CoverLayout from "@/Layouts/CoverLayout";

export default {
  components: {
    Header,
    Notification,
    Footer,
    CoverLayout,
  },
};
</script>
<style scoped>
 #bg-projets{
    background:url('../../../../public/storage/assets/web/image/fond-projets.jpg') #111 no-repeat;
    background-position: 0% 0%;
  background-size: 100% auto;
 }
@media screen and (min-width:800px) {
  #bg-projets{
  min-height: 350px;
  }
}
  
</style>
